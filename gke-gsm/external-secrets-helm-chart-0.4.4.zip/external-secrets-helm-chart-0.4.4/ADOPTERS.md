# External Secrets Operator Adopters

<!-- Add yourself here if you are using ESO in your company or your project! -->

- [Polarpoint](https://www.polarpoint.io/)
- [Pento](https://www.pento.io/)
- [Mixpanel](https://mixpanel.com)
- [K8S Website Infra](https://k8s.io/)


Countless others that can't disclose that information! :)
