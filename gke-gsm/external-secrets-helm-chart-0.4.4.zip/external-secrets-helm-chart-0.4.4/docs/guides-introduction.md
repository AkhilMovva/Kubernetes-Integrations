# Guides

The following guides demonstrate use-cases and provide examples of how to use
the API. Please pick one of the following guides:

* [Getting started](guides-getting-started.md)
* [Advanced Templating](guides-templating.md)
* [Multi-Tenancy Design Considerations](guides-multi-tenancy.md)
